## Usage

```
실행 (실행 결과 출력)
bash scripts/run.sh <테스트명> -m run

테스트 (pass or fail)
bash scripts/run.sh <테스트명> -m test

디버그
bash scripts/run.sh <테스트명> -m debug
```

e.g. `bash scripts/run.sh args-none -m run`