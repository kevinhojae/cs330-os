cd /root/cs330-os/vm
make clean
make
make check