#!/bin/bash

cd /root/cs330-os/vm
make clean
make