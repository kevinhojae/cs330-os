cd /root/cs330-os/userprog
make clean
make
make check