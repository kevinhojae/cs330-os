#!/bin/bash

cd /root/cs330-os/userprog
make clean
make